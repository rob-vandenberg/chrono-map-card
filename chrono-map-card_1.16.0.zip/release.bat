@echo off
setlocal enabledelayedexpansion

:: -----------------------------------------------------------------------------
:: release.bat -- release script for chrono-map-card.
:: Local machine only: backs up source, commits, and pushes to main.
:: Building (rollup + terser) happens on GitHub via build.yml.
:: Tagging and the GitHub release happen separately via publish.yml.
:: Version lives in package.json (not a CARD_VERSION source constant).
:: -----------------------------------------------------------------------------

for %%F in ("%CD%") do set "PROJECT_IDENTIFIER=%%~nxF"

:: ANSI color codes (requires Windows 10 1511+)
for /f %%A in ('echo prompt $E ^| cmd') do set "ESC=%%A"
set "RESET=%ESC%[0m"
set "WHITE=%ESC%[97m"
set "BLUE=%ESC%[94m"
set "GREEN=%ESC%[92m"
set "RED=%ESC%[91m"

:: ============================================================
echo.
echo %BLUE%[STEP 1]%WHITE% Extracting version from package.json...%RESET%
:: ============================================================
if not exist "package.json" (
    echo %RED%!! ERROR: package.json not found in this folder !!%RESET%
    pause & exit /b 1
)

for /f "tokens=2 delims=:," %%A in ('findstr /C:"\"version\"" package.json') do (
    set "CARD_VERSION=%%~A"
)
set "CARD_VERSION=%CARD_VERSION: =%"
set "CARD_VERSION=%CARD_VERSION:"=%"

if "%CARD_VERSION%"=="" (
    echo %RED%!! ERROR: Could not find "version" in package.json !!%RESET%
    pause & exit /b 1
)
set "TAG_NAME=v%CARD_VERSION%"

echo  PROJECT:      %PROJECT_IDENTIFIER%
echo  CARD_VERSION: %CARD_VERSION%
echo  TAG:          %TAG_NAME%

:: ============================================================
echo.
echo %BLUE%[STEP 2]%WHITE% Determining release mode...%RESET%
:: ============================================================
:: Checks whether publish.yml has already tagged this version on a
:: previous run. This script never creates or pushes tags itself.
git rev-parse "%TAG_NAME%" >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set MODE=UPDATE
) else (
    set MODE=RELEASE
)
echo  MODE: %MODE%

:: ============================================================
echo.
echo %BLUE%[STEP 3]%WHITE% Validating commit message...%RESET%
:: ============================================================
set MSG=%~1

if "%MODE%"=="RELEASE" (
    if "%MSG%"=="" (
        echo.
        echo %RED%!! ERROR: A comment is REQUIRED for a new release. !!%RESET%
        echo %RED%!! Usage: release.bat "Your commit message"        !!%RESET%
        pause & exit /b 1
    )
    echo  MESSAGE: %MSG%
) else (
    echo  MESSAGE: N/A - UPDATE mode
)

:: ============================================================
echo.
echo %BLUE%[STEP 4]%WHITE% Creating backup zip of source files...%RESET%
:: ============================================================
set BACKUP_FILE=backup\%PROJECT_IDENTIFIER%_%CARD_VERSION%.zip

if exist "%BACKUP_FILE%" (
    attrib -r "%BACKUP_FILE%"
    del /f "%BACKUP_FILE%"
)

if not exist backup mkdir backup

"C:\Program Files\7-Zip\7z.exe" a "%BACKUP_FILE%" src\* package.json rollup.config.js -r >nul
if %ERRORLEVEL% NEQ 0 (
    echo %RED%!! ERROR: Backup zip failed. Check 7-Zip installation. !!%RESET%
    pause & exit /b 1
)
echo %GREEN%[BACKUP] %BACKUP_FILE%%RESET%
attrib +r "%BACKUP_FILE%"

:: ============================================================
echo.
echo %BLUE%[STEP 5]%WHITE% Staging and committing to git...%RESET%
:: ============================================================
git add . -v

if "%MODE%"=="UPDATE" (
    git commit --amend --no-edit
) else (
    git commit -m "%MSG%"
)

:: ============================================================
echo.
echo %BLUE%[STEP 6]%WHITE% Pushing to GitHub...%RESET%
:: ============================================================
git push origin main --force

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo %RED%!! ERROR: Git Push failed !!%RESET%
    pause & exit /b 1
)

echo.
echo %GREEN%===========================================%RESET%
echo %GREEN% SUCCESS! %MODE% pushed for %TAG_NAME%%RESET%
echo %GREEN% Next: wait for build.yml / validate_hacs.yml,%RESET%
echo %GREEN% then run publish.yml manually on GitHub.%RESET%
echo %GREEN%===========================================%RESET%
pause
